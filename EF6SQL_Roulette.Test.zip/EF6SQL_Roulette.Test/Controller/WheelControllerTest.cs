﻿using EF6SQLite_Roulette.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FakeItEasy;
using EF6SQLite_Roulette.Models;
using EF6SQLite_Roulette.Controllers;
using EF6SQLite_Roulette.Logic.Interface;
using EF6SQLite_Roulette.Logic.Services;
using Microsoft.AspNetCore.Mvc;

namespace EF6SQL_Roulette.Test.Controller
{
    public class WheelControllerTest
    {
        [Fact]
        public async Task ColourPicked_ReturnOk()
        {
            //Arrange
            //var dbcon = A.Fake<RouletteDbContext>();

            var dbContext = A.Fake<IRouletteDbServices>();
            var wheelServices = A.Fake<IWheelBaordServices>();
            var ControllerWheel = new WheelController(wheelServices, dbContext);

            //Act
            var actionResult = await ControllerWheel.ColourPicked("Black");


            var getStatusCode = new OkObjectResult(actionResult);

            var valueofStatusCode = getStatusCode.StatusCode;

            //Assert
            Assert.Equal(200, valueofStatusCode);



        }

        [Fact]
        public async Task GetOdd_ReturnOk()
        {
            //Arrange

            var dbContext = A.Fake<IRouletteDbServices>();
            var wheelServices = A.Fake<IWheelBaordServices>();
            var ControllerWheel = new WheelController(wheelServices, dbContext);


            //Act
            var result = await ControllerWheel.ODDorEvenPicked("Odd");
            var getStatusCode = new OkObjectResult(result);

            var valueofStatusCode = getStatusCode.StatusCode;

            //Assert
            Assert.Equal(200, valueofStatusCode);

        }


        [Fact]
        public async Task GetNumberPicked_ReturnOk()
        {
            //Arrange

            var dbContext = A.Fake<IRouletteDbServices>();
            var wheelServices = A.Fake<IWheelBaordServices>();
            //A.CallTo(() => wheelServices.ColourPicked("Odd").Status.Equals(200));
            var ControllerWheel = new WheelController(wheelServices, dbContext);

            //Act
            var result = await ControllerWheel.NumberPicked(4);
            var getStatusCode = new OkObjectResult(result);

            var valueofStatusCode = getStatusCode.StatusCode;

            //Assert
            Assert.Equal(200, valueofStatusCode);

        }




    }

}





